package Client.Model.Employee.EmployeeOverview;

import java.util.ArrayList;

public interface EmployeeOverviewModel
{
  ArrayList<String> getRequests();
  void employeeLogOut();
}
