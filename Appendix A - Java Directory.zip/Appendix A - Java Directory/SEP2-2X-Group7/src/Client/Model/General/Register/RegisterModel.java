package Client.Model.General.Register;

public interface RegisterModel
{
  void signup(String username,String type, String fName, String lName, String address, String dob, String phone);
}
