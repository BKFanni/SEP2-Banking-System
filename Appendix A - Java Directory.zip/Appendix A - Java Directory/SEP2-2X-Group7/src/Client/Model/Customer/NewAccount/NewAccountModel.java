package Client.Model.Customer.NewAccount;

public interface NewAccountModel
{
  void newAccount(String username,String type, String amount);
}
