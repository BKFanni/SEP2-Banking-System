package Client.Model.Customer.DeleteAccount;

import Client.Networking.Client;

/**
 * @author
 * Class that is implementing DeleteAccountModel interface
 */
public class DeleteAccountModelImpl implements DeleteAccountModel
{
    private static DeleteAccountModel instance;

    private Client client;

    /**
     * Constructor that initialises the client
     */
    private DeleteAccountModelImpl(Client client)
    {
        this.client=client;
    }

    /**
     * Method that instantiates the singleton
     * @return instance object
     */
    public static DeleteAccountModel getInstance(Client client)
    {
        if(instance==null) instance=new DeleteAccountModelImpl(client);
        return instance;
    }

    /**
     * Method that deletes an account
     * @param accountNo the account number of the user
     */
    public void deleteAccount(String accountNo)
    {
        client.deleteAccount(accountNo);
    }
}
