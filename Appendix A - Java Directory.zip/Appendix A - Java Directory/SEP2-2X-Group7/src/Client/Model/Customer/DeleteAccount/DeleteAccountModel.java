package Client.Model.Customer.DeleteAccount;

public interface DeleteAccountModel
{
    void deleteAccount(String accountNo);
}
