package Client.Model.Customer.Profile;

public interface ProfileModel
{
  String getFullName(String username);
  void customerLogOut();
}
