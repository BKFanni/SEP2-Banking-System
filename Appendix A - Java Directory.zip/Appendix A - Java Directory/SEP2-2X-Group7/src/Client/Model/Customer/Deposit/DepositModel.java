package Client.Model.Customer.Deposit;

public interface DepositModel
{
  void deposit(String username,String amount,String cardNo,String cvv,String expDate);
}
