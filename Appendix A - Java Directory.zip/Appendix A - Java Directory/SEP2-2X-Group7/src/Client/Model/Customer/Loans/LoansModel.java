package Client.Model.Customer.Loans;

import java.util.ArrayList;

public interface LoansModel
{
  ArrayList<String> getLoans(String accountNo);
}
