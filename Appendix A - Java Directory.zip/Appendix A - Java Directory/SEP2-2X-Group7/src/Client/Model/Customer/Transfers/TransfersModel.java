package Client.Model.Customer.Transfers;

import java.util.ArrayList;

public interface TransfersModel
{
  ArrayList<String> getTransfers(String accountNo);
}
