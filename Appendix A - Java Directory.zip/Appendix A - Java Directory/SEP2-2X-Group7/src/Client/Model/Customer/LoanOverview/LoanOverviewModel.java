package Client.Model.Customer.LoanOverview;

import java.util.ArrayList;

public interface LoanOverviewModel
{
    ArrayList<String> getLoan(String loanNo);
}
