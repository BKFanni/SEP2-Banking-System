package Client.Model.Customer.NewLoan;

import Client.Networking.Client;

/**
 * @author
 * Class that is implementing NewLoanModel interface
 */
public class NewLoanModelImpl implements NewLoanModel
{
  private static NewLoanModel instance;
  private Client client;

  /**
   * Constructor that initialises the client
   */
  private NewLoanModelImpl(Client client)
  {
    this.client=client;
  }

  /**
   * Method that instantiates the singleton
   * @return instance object
   */
  public static NewLoanModel getInstance(Client client)
  {
    if(instance==null) instance=new NewLoanModelImpl(client);
    return instance;
  }

  /**
   * Method that makes a new loan
   * @param accountNo the account number
   * @param amount the amount of the loan
   * @param interest the interest rate of the loan
   * @param tenure the tenure
   * @param totalPayback the total payback
   */
  public void newLoan(String accountNo,double amount,double interest,String tenure,double totalPayback)
  {
    client.newLoan(accountNo,amount,interest,tenure,totalPayback);
  }
}
