package Client.Model.Customer.NewLoan;

public interface NewLoanModel
{
    void newLoan(String accountNo,double amount,double interest,String tenure,double totalPayback);
}
