package Client.Model.Customer.MakeTransfer;

public interface MakeTransferModel
{
//  int transfer(String username,String accountNo,String recAccNo,String recSwift,String amount);
  boolean internalTransfer(String accNo,String amount,String recipientAccNo);
  void externalTransfer(String accNo,String username,String amount,String iban,String bankName,String swift);

  boolean available(String accountNo, double amount);
}
