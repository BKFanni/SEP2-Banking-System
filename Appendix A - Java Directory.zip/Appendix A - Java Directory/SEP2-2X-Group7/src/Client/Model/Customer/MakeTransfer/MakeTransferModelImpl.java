package Client.Model.Customer.MakeTransfer;

import Client.Networking.Client;

/**
 * @author
 * Class that is implementing MakeTransferModel interface
 */
public class MakeTransferModelImpl implements MakeTransferModel
{
  private static MakeTransferModel instance;
  private Client client;

  /**
   * Constructor that initialises the client
   */
  private MakeTransferModelImpl(Client client)
  {
    this.client=client;
  }

  /**
   * Method that instantiates the singleton
   * @return instance object
   */
  public static MakeTransferModel getInstance(Client client)
  {
    if(instance==null) instance=new MakeTransferModelImpl(client);
    return instance;
  }

  /**
   * Method that makes an internal transfer
   * @param accNo the account number of the user
   * @param amount the amount to be transferred
   * @param recipientAccNo recipient account number
   * @return the internal transfer
   */
  public boolean internalTransfer(String accNo,String amount,String recipientAccNo)
  {
    return client.internalTransfer(accNo,amount,recipientAccNo);
  }

  public void externalTransfer(String accNo,String username,String amount,String iban,String bankName,String swift)
  {
    client.externalTransfer(accNo,username,amount,iban,bankName,swift);
  }

  /**
   * Method that checks to see if the amount intended for transfer is smaller than account's balance value
   * @param accountNo the ccount number of the user
   * @param amount the amount to be compared
   * @return true if the amount is smaller or equal to account's ballance, false otherwise
   */
  public boolean available(String accountNo, double amount)
  {
    Double balance = Double.parseDouble(client.getBalance(accountNo));
    return amount<=balance;
  }
}
