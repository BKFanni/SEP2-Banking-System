package Client.View.Customer.MakeTransfer;

import Client.Model.Customer.MakeTransfer.MakeTransferModel;

public class MakeTransferViewModel
{
  private MakeTransferModel model;

  public MakeTransferViewModel(MakeTransferModel model)
  {
    this.model=model;
  }

  public boolean internalTransfer(String accNo,String amount,String recipientAccNo)
  {
    return model.internalTransfer(accNo,amount,recipientAccNo);
  }

  public void externalTransfer(String accNo,String username,String amount,String iban,String bankName,String swift)
  {
    model.externalTransfer(accNo,username,amount,iban,bankName,swift);
  }

  public boolean available(String accountNo, String amount)
  {
    double money = Double.parseDouble(amount);
    return model.available(accountNo,money);
  }
}
