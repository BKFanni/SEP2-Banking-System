package Client.View.Customer.MakeTransfer;

import Client.Core.ViewHandler;
import Client.Core.ViewModelFactory;
import Client.View.ViewController;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javax.swing.*;
import java.io.IOException;

public class MakeTransferViewController implements ViewController
{
  private ViewHandler viewHandler;
  private MakeTransferViewModel viewModel;
  private String username;
  private String accountNo;
  @FXML TextField amountTextField;
  @FXML TextField accountNoTextField;
  @FXML TextField swiftTextField;
  @FXML TextField ibanTextField;
  @FXML TextField bankNameTextField;
  @FXML Button internalSendButton;
  @FXML Button externalSendButton;
  @FXML Button overviewButton;
  @FXML Button profileButton;
  @FXML Button transfersButton;

  public void init(ViewHandler viewHandler, ViewModelFactory viewModelFactory, String username)
  {
    this.username=username;
    this.viewHandler=viewHandler;
    viewModel=viewModelFactory.getMakeTransferViewModel();
  }

  public void initPlus(ViewHandler viewHandler, ViewModelFactory viewModelFactory, String username,String accountNo)
  {
    init(viewHandler,viewModelFactory,username);
    this.accountNo=accountNo;
  }

  public void onOverviewButton() throws IOException
  {
    viewHandler.openOverviewView(username,accountNo);
  }

  public void onTransfersButton() throws IOException
  {
    viewHandler.openTransfersView(username,accountNo);
  }

  public void onProfileButton() throws IOException
  {
    viewHandler.openProfileView(username);
  }

  public void onInternalSendButton() throws IOException
  {
    if(available())
    {
      if (accountNoTextField.getText().isEmpty() || amountTextField.getText().isEmpty())
      {
        JOptionPane.showMessageDialog(null, "Please fill in all fields");
      }
      else
      {
        boolean result = viewModel.internalTransfer(accountNo, amountTextField.getText(), accountNoTextField.getText());
        if (result) JOptionPane.showMessageDialog(null, "Funds transferred");
        else JOptionPane.showMessageDialog(null, "Outstanding transfer (>9.999 DKK) awaiting approval, est. 24hr");
        viewHandler.openOverviewView(username, accountNo);
      }
    }
    else JOptionPane.showMessageDialog(null, "Insufficient funds");

  }

  public void onExternalSendButton() throws IOException {
    if (available()) {
      if (ibanTextField.getText().isEmpty() || bankNameTextField.getText().isEmpty() || swiftTextField.getText().isEmpty())
      {
        JOptionPane.showMessageDialog(null, "Please fill in all fields");
      }
      else
      {
        viewModel.externalTransfer(accountNo, username, amountTextField.getText(), ibanTextField.getText(), bankNameTextField.getText(), swiftTextField.getText());
        JOptionPane.showMessageDialog(null, "International Transfer awaiting approval, est. 24hr");
        viewHandler.openOverviewView(username, accountNo);
      }
    }
    else JOptionPane.showMessageDialog(null, "Insufficient funds");
  }

  private boolean available()
  {
    return viewModel.available(accountNo,amountTextField.getText());
  }
}
