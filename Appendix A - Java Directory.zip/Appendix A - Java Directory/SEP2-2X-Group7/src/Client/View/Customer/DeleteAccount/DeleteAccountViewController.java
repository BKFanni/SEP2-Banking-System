package Client.View.Customer.DeleteAccount;

import Client.Core.ViewHandler;
import Client.Core.ViewModelFactory;
import Client.View.ViewController;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import javax.swing.*;
import java.io.IOException;

public class DeleteAccountViewController implements ViewController
{
    private String username, accountNo;
    private ViewHandler viewHandler;
    private DeleteAccountViewModel viewModel;

    @FXML Button overviewButton;
    @FXML Button transfersButton;
    @FXML Button profileButton;


    public void init(ViewHandler viewHandler, ViewModelFactory viewModelFactory, String username) {
        this.viewHandler=viewHandler;
        viewModel = viewModelFactory.getDeleteAccountViewModel();
        this.username=username;
    }

    public void initPlus(ViewHandler viewHandler, ViewModelFactory viewModelFactory, String username, String accountNo)
    {
        init(viewHandler,viewModelFactory,username);
        this.accountNo=accountNo;
    }

    public void onCancelButton() throws IOException
    {
        viewHandler.openAccountListView(username);
    }

    public void onDeleteButton() throws IOException
    {
        viewModel.deleteAccount(accountNo);
        JOptionPane.showMessageDialog(null,"Request to delete account submitted");
        viewHandler.openAccountListView(username);
    }

    public void onProfileButton() throws IOException
    {
        viewHandler.openProfileView(username);
    }

    public void onTransfersButton() throws IOException
    {
        viewHandler.openTransfersView(username,accountNo);
    }

    public void onOverviewButton() throws IOException
    {
        viewHandler.openOverviewView(username,accountNo);
    }
}
