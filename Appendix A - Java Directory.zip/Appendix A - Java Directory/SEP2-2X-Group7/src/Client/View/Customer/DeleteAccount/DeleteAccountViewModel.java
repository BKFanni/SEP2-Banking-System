package Client.View.Customer.DeleteAccount;

import Client.Model.Customer.DeleteAccount.DeleteAccountModel;

public class DeleteAccountViewModel
{
    private DeleteAccountModel model;

    public DeleteAccountViewModel(DeleteAccountModel model)
    {
        this.model=model;
    }

    public void deleteAccount(String accountNo)
    {
        model.deleteAccount(accountNo);
    }
}
