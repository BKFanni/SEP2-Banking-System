package Client.View.Customer.LoanOverview;

import Client.Model.Customer.LoanOverview.LoanOverviewModel;

import java.util.ArrayList;

public class LoanOverviewViewModel
{
  private LoanOverviewModel model;

  public LoanOverviewViewModel(LoanOverviewModel model)
  {
    this.model=model;
  }

  public ArrayList<String> getLoan(String loanNo)
  {
    return model.getLoan(loanNo);
  }
}
