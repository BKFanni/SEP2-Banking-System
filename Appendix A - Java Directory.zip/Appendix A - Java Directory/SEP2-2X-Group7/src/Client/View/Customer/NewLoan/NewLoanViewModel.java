package Client.View.Customer.NewLoan;

import Client.Model.Customer.NewLoan.NewLoanModel;

public class NewLoanViewModel
{
  private NewLoanModel model;

  public NewLoanViewModel(NewLoanModel model)
  {
    this.model=model;
  }

  public void newLoan(String accountNo,double amount,double interest,String tenure,double totalPayback)
  {
    model.newLoan(accountNo,amount,interest,tenure,totalPayback);
  }
}
