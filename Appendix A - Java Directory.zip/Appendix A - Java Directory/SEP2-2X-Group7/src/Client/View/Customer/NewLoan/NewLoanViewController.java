package Client.View.Customer.NewLoan;

import Client.Core.ViewHandler;
import Client.Core.ViewModelFactory;
import Client.View.ViewController;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;

import javax.swing.*;
import java.io.IOException;

public class NewLoanViewController implements ViewController
{
  private ViewHandler viewHandler;
  private NewLoanViewModel viewModel;
  private String username;
  private String accountNo;
  @FXML TextField amountTextField;
  @FXML TextField interestRateTextField;
  @FXML ChoiceBox tenureChoiceBox;
  @FXML TextField totalPaybackTextField;
  @FXML Button requestButton;
  @FXML Button overviewButton;
  @FXML Button transfersButton;
  @FXML Button profileButton;
  @FXML Button checkButton;

  public void init(ViewHandler viewHandler, ViewModelFactory viewModelFactory, String username)
  {
    this.viewHandler=viewHandler;
    this.username=username;
    viewModel=viewModelFactory.getNewLoanViewModel();
    tenureChoiceBox.getItems().add("12 months");
    tenureChoiceBox.getItems().add("24 months");
    tenureChoiceBox.getItems().add("36 months");
    tenureChoiceBox.getItems().add("48 months");
    tenureChoiceBox.getItems().add("60 months");
  }
  public void initPlus(ViewHandler viewHandler,ViewModelFactory viewModelFactory,String username,String accountNo)
  {
    init(viewHandler,viewModelFactory,username);
    this.accountNo=accountNo;
  }

  public void onRequestButton() throws IOException
  {
    if(validate())
    {
      System.out.printf(accountNo);
      double amount = Double.parseDouble(amountTextField.getText());
      double interest = Double.parseDouble(interestRateTextField.getText());
      String tenure = (String)tenureChoiceBox.getSelectionModel().getSelectedItem();
      double totalPayback = Double.parseDouble(totalPaybackTextField.getText());
      viewModel.newLoan(accountNo,amount,interest,tenure,totalPayback);
      JOptionPane.showMessageDialog(null,"Request for new loan created");
      viewHandler.openOverviewView(username,accountNo);
    }
  }

  public void onOverviewButton() throws IOException
  {
    viewHandler.openOverviewView(username,accountNo);
  }

  public void onTransfersButton() throws IOException
  {
    viewHandler.openTransfersView(username,accountNo);
  }

  public void onProfileButton() throws IOException
  {
    viewHandler.openProfileView(username);
  }

  public void onCheckButton()
  {
    double amount = Double.parseDouble(amountTextField.getText());
    double interest = Double.parseDouble(interestRateTextField.getText())*0.01;
    String tenure = (String)tenureChoiceBox.getSelectionModel().getSelectedItem();

    if(tenure.equals("12 months"))
    {
      String totalPayback= String.valueOf(amount + (amount*interest)*12);
      totalPaybackTextField.setText(totalPayback);
    }
    if(tenure.equals("24 months"))
    {
      String totalPayback= String.valueOf(amount + (amount*interest)*24);
      totalPaybackTextField.setText(totalPayback);
    }
    if(tenure.equals("36 months"))
    {
      String totalPayback= String.valueOf(amount + (amount*interest)*36);
      totalPaybackTextField.setText(totalPayback);
    }
    if(tenure.equals("48 months"))
    {
      String totalPayback= String.valueOf(amount + (amount*interest)*48);
      totalPaybackTextField.setText(totalPayback);
    }
    if(tenure.equals("60 months"))
    {
      String totalPayback= String.valueOf(amount + (amount*interest)*60);
      totalPaybackTextField.setText(totalPayback);
    }
  }
  private boolean validate()
  {
    String amount = amountTextField.getText();
    if(amount.charAt(0)=='0')
    {
      JOptionPane.showMessageDialog(null,"Invalid amount value");
      return false;
    }
    String legal ="1234567890.";
    for(int i=0;i<amount.length();i++)
    {
      if(!legal.contains(amount.charAt(i)+""))
      {
        JOptionPane.showMessageDialog(null,"Invalid amount value");
        return false;
      }
    }
    double amount2 = Double.parseDouble(amount);
    if(amount2<1000)
    {
      JOptionPane.showMessageDialog(null,"Minimum amount 1000 DKK");
      return false;
    }

    String interest = interestRateTextField.getText();
    for(int i=0;i<interest.length();i++)
    {
      if(!legal.contains(interest.charAt(i)+""))
      {
        JOptionPane.showMessageDialog(null,"Invalid interest value");
        return false;
      }
    }
    double interest2 = Double.parseDouble(interest);
    if(!(interest2>=5 && interest2<=35))
    {
      JOptionPane.showMessageDialog(null,"Interest value must be between 5% - 35%");
      return false;
    }
    return true;
  }
}
